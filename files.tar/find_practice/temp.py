import os
import random

for i in range(25000):
	location = [chr(random.randint(ord("A"),ord("Z"))) for i in range(50)]
	os.makedirs("/".join(location))
